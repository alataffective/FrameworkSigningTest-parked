//
//  ThemeKit.h
//  ThemeKit
//
//  Created by Nuno Grilo on 21/09/2016.
//  Copyright © 2016-2017 Paw & Nuno Grilo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for ThemeKit.
FOUNDATION_EXPORT double ThemeKitVersionNumber;

//! Project version string for ThemeKit.
FOUNDATION_EXPORT const unsigned char ThemeKitVersionString[];
